./nanoappend Alfa ../ Alfa_summary.xml

